package com.example.posttest3_1915016104_josuaimanuelsamuelkanter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
