import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int angka = 0;
  TextEditingController controllerJudul = TextEditingController();
  TextEditingController controllerTahun = TextEditingController();
  TextEditingController controllerRating = TextEditingController();
  TextEditingController controllerDeskripsi = TextEditingController();
  TextEditingController controllerTipe = TextEditingController();
  TextEditingController controllerCost = TextEditingController();
  String judulFilm = "",
      tahunRilis = "",
      ratingFilm = "",
      deskFilm = "",
      productionCost = "";
  bool? nilaiCheckBox = false;
  // bool checkbox1 = false;
  List<String> genre = ["Sleeping", "Singing", "Dancing"];
  List<String> tipe = ["Movie", "Series"];
  String hobiGroup = "";
  String tipeGroup = "", hasiltipe = "";
  String genreGroup = "";

  @override
  void initState() {
    controllerJudul.text = "";
    controllerTahun.text = "";
    controllerRating.text = "";
    controllerDeskripsi.text = "";
    super.initState();
  }

  @override
  void dispose() {
    controllerJudul.dispose();
    controllerTahun.dispose();
    controllerRating.dispose();
    controllerDeskripsi.dispose();
    controllerCost.dispose();
    super.dispose();
  }

  void hapusValue() {
    controllerJudul.text = "";
    controllerTahun.text = "";
    controllerRating.text = "";
    controllerCost.text = "";
    controllerDeskripsi.text = "";
  }

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    var tinggi = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {},
          icon: Icon(Icons.chevron_left),
        ),
        title: Text("Form Data Film"),
        backgroundColor: Color.fromARGB(255, 6, 97, 99),
      ),
      body: ListView(
        padding: EdgeInsets.all(20.0),
        children: [
          Container(
            width: lebar,
            // height: 200,
            padding: EdgeInsets.only(top: 10, bottom: 10),
            margin: EdgeInsets.only(bottom: 20),
            child: const Text(
              "SILAHKAN ISI DATA FILM",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Color.fromARGB(255, 205, 190, 120),
              ),
            ),
            color: Color.fromARGB(255, 56, 56, 56),
          ),
          Column(
            children: [
              TextField(
                controller: controllerJudul,
                decoration: const InputDecoration(
                  hintText: "Masukkan Judul Film",
                  labelText: "Judul Film",
                  border: OutlineInputBorder(),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: Colors.lime,
                    ),
                  ),
                  icon: Icon(
                    Icons.local_movies,
                    color: Color.fromARGB(255, 6, 97, 99),
                  ),
                ),
              ),
              SizedBox(height: 15),
              TextField(
                controller: controllerTahun,
                decoration: const InputDecoration(
                  icon: Icon(
                    Icons.today,
                    color: Color.fromARGB(255, 6, 97, 99),
                  ),
                  hintText: "Masukkan Tahun Rilis Film",
                  labelText: "Tahun Rilis",
                  border: OutlineInputBorder(),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: Colors.lime,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 15),
              TextField(
                controller: controllerRating,
                decoration: const InputDecoration(
                  hintText: "Masukkan Rating FIlm",
                  labelText: "Rating",
                  border: OutlineInputBorder(),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: Colors.lime,
                    ),
                  ),
                  icon: Icon(
                    Icons.filter_9_plus_rounded,
                    color: Color.fromARGB(255, 6, 97, 99),
                  ),
                ),
              ),
              SizedBox(height: 15),
              TextField(
                controller: controllerCost,
                decoration: const InputDecoration(
                  hintText: "Masukkan Biaya Produksi",
                  labelText: "Biaya Produksi",
                  border: OutlineInputBorder(),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: Colors.lime,
                    ),
                  ),
                  icon: Icon(
                    Icons.monetization_on,
                    color: Color.fromARGB(255, 6, 97, 99),
                  ),
                ),
              ),
              SizedBox(height: 15),
              TextFormField(
                maxLines: 7,
                controller: controllerDeskripsi,
                decoration: const InputDecoration(
                  hintText: "Masukkan Deskripsi Film",
                  labelText: "Deskripsi",
                  border: OutlineInputBorder(),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: Colors.lime,
                    ),
                  ),
                  icon: Icon(
                    Icons.library_books,
                    color: Color.fromARGB(255, 6, 97, 99),
                  ),
                ),
              ),
              SizedBox(height: 15),
              Row(
                children: <Widget>[
                  const Icon(
                    Icons.movie,
                    color: Color.fromARGB(255, 6, 97, 99),
                  ),
                  for (var item in tipe)
                    Row(
                      children: [
                        Radio(
                          value: item,
                          groupValue: tipeGroup,
                          onChanged: (newValue) {
                            setState(() {
                              tipeGroup = newValue.toString();
                            });
                          },
                        ),
                        Text(item),
                      ],
                    ),
                ],
              ),
              SizedBox(height: 15),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    judulFilm = controllerJudul.text;
                    tahunRilis = controllerTahun.text;
                    ratingFilm = controllerRating.text;
                    deskFilm = controllerDeskripsi.text;
                    productionCost = controllerCost.text;
                    hasiltipe = tipeGroup;
                    // hapusValue();
                  });
                },
                child: Text("Submit"),
                style: ElevatedButton.styleFrom(
                  primary: Color.fromARGB(255, 6, 97, 99),
                ),
              ),
              SizedBox(height: 50),
            ],
          ),
          Column(
            children: [
              Text(
                "Judul Film : $judulFilm\n\n" +
                    "Tahun Rilis : $tahunRilis\n\n" +
                    "Rating Film : $ratingFilm\n\n" +
                    "Biaya Produksi : $productionCost\n\n" +
                    "Deskripsi : $deskFilm\n\n" +
                    "hasil radio Button adalah : $hasiltipe\n\n",
                textAlign: TextAlign.left,
              ),
              // Text(),
              // Text("Rating Film : $ratingFilm"),
              // Text("Biaya Produksi : $productionCost"),
              // Text("Deskripsi : $deskFilm"),
              // Text("hasil radio Button adalah : $hasiltipe"),
            ],
          ),
        ],
      ),
    );
  }
}
